# pip install pyzmq cbor keyboard
from zmqRemoteApi import RemoteAPIClient
import keyboard
import random

client = RemoteAPIClient('localhost', 23000)

print('Program started')
sim = client.getObject('sim')
sim.startSimulation()
print('Simulation started')

def setBubbleRobVelocity(leftWheelVelocity, rightWheelVelocity):
    leftMotor = sim.getObject('/leftMotor2')
    rightMotor = sim.getObject('/rightMotor2')
    
    sim.setJointTargetVelocity(leftMotor, leftWheelVelocity)
    sim.setJointTargetVelocity(rightMotor, rightWheelVelocity)

'''
# Example usage 1:
setBubbleRobVelocity(1.0, 1.0)
time.sleep(2)
setBubbleRobVelocity(0.0, 0.0)
'''
size = [0.2, 0.2, 0.2]
position = [0, 0, 0.5]
options = 8
# Create the cuboid
#ball = sim.createPureShape(1, options, size, 1, None)
#sim.setObjectPosition(ball, -1, position)
#ball = sim.getObject('/Sphere')
#sim.setObjectSpecialProperty(ball, sim.objectspecialproperty_detectable)

# use keyborad to move BubbleRob

while True:
    a = sim.getObject('/Sphere')
    b =sim.getObjectPosition(a,-1)
    if b[1]<-2.15:
        sim.removeObject(a)
        ball = sim.createPureShape(1, options, size, 1, None)
        position2= [random.uniform(-1,1), random.uniform(-1,1), 0.5]
        sim.setObjectPosition(ball, -1, position2)
        ball = sim.getObject('/Sphere')
        sim.setObjectSpecialProperty(ball, sim.objectspecialproperty_detectable)
    if keyboard.is_pressed('up'):
        setBubbleRobVelocity(4.0, 4.0)
    elif keyboard.is_pressed('down'):
        setBubbleRobVelocity(-3.0, -3.0)
    elif keyboard.is_pressed('left'):
        setBubbleRobVelocity(-2.0, 2.0)
    elif keyboard.is_pressed('right'):
        setBubbleRobVelocity(2.0, -2.0)
    elif keyboard.is_pressed('q'):
        # stop simulation
        sim.stopSimulation()
    else:
        setBubbleRobVelocity(0.0, 0.0)




